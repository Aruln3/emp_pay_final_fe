export class Attendance {

    id!: number;
    emp_name!: string;
    email!: string;
    date!: Date;
    emp_id:any;
    status!: string;
    
}
